package br.com.tiacademy.nascimentos.core.crud;

public interface CrudDomain<ID> {

    ID getId();

}

package br.com.tiacademy.nascimentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NascimentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(NascimentosApplication.class, args);
	}

}

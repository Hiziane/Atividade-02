package br.com.tiacademy.nascimentos.service;

import br.com.tiacademy.nascimentos.core.crud.CrudService;
import br.com.tiacademy.nascimentos.domain.Bezerro;
import org.springframework.stereotype.Service;

@Service
public class BezerroService extends CrudService<Bezerro,Long> {
    @Override
    protected Bezerro editarEntidade(Bezerro recuperado, Bezerro entidade) {
        recuperado.setId(entidade.getId());
        recuperado.setAdapar(entidade.getAdapar());
        recuperado.setRegistro(entidade.getRegistro());

        return recuperado;
    }

}

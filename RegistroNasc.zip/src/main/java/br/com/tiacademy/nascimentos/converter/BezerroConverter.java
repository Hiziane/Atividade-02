package br.com.tiacademy.nascimentos.converter;

import br.com.tiacademy.nascimentos.core.crud.CrudConverter;
import br.com.tiacademy.nascimentos.domain.Bezerro;
import br.com.tiacademy.nascimentos.dto.BezerroDTO;
import org.springframework.stereotype.Component;

@Component
public class BezerroConverter implements CrudConverter<Bezerro, BezerroDTO> {
    @Override
    public BezerroDTO entidadeParaDTO(Bezerro entidade) {
        //return new BezerroDTO(entidade.getId(),entidade.getStatus(),entidade.getAdapar(),entidade.getDataNasc(),entidade.getDataVenda(),entidade.getRegistro(),entidade.getSexo(),entidade.getValor());
        return null;
    }

    @Override
    public Bezerro dtoParaEntidade(BezerroDTO dto) {

        //return new Bezerro(dto.getId(),dto.getStatus(),dto.getAdapar(),dto.getDataNasc(),dto.getDataVenda(),dto.getRegistro(),dto.getSexo(),dto.getValor());
        return null;
    }
}
